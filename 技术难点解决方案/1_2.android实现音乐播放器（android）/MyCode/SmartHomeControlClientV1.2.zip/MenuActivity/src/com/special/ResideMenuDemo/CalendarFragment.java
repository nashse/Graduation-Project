package com.special.ResideMenuDemo;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.util.ArrayList;
import java.util.List;

/**
 * User: special
 * Date: 13-12-22
 * Time: 下午3:26
 * Mail: specialcyci@gmail.com
 */
public class CalendarFragment extends Fragment {

    private View parentView;
    private ListView listView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parentView = inflater.inflate(R.layout.calendar, container, false);
        listView   = (ListView) parentView.findViewById(R.id.listView);
        initView();
        return parentView;
    }

    private void initView(){
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_list_item_checked,
                getCalendarData());
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getActivity(), "Clicked item!", Toast.LENGTH_LONG).show();
            }
        });
    }

    private ArrayList<String> getCalendarData(){
        ArrayList<String> calendarList = new ArrayList<String>();
        
        calendarList.add("SSH框架搭建与配置");
        calendarList.add("SSH框架与mysql连接，实现CRUD");
        calendarList.add("用python的Django框架搭建后台管理系统");
        calendarList.add("websocket实现远程控制音乐播放器播放");
        calendarList.add("android实现渐隐特效的开机界面");
        calendarList.add("相关开源组件配置与使用（Sliding Menu）");
        calendarList.add("服务器端搭建webservice服务");
        calendarList.add("UI素材收集");
        calendarList.add("Gradle配置");
        calendarList.add("需求分析");
        calendarList.add("系统设计");
        calendarList.add("数据库设计");        
        calendarList.add("编写文档");
        calendarList.add("android界面跳转");
        
        return calendarList;
    }
}
