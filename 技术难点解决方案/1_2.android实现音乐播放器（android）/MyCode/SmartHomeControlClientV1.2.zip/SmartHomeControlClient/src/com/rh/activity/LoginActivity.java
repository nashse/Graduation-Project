package com.rh.activity;

import com.special.ResideMenuDemo.MenuActivity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.app.Activity;
import android.content.Intent;


public class LoginActivity extends Activity {
	Button btn_login = null;
	EditText etxt_user_name = null;
	EditText etxt_user_pwd = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		btn_login = (Button)findViewById(R.id.btn_login);
		etxt_user_name = (EditText)findViewById(R.id.etxt_username);
		etxt_user_pwd = (EditText)findViewById(R.id.etxt_pwd);
		
		//���õ�¼��ť����
		btn_login.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String userName = etxt_user_name.getText().toString().trim();
				String userPwd =etxt_user_pwd.getText().toString().trim();
				if (userName.equals("root") && userPwd.equals("root")) {
					Intent intent = new Intent();
					intent.setClass(LoginActivity.this,MenuActivity.class);
					startActivity(intent);
				}
				else {
					Toast.makeText(LoginActivity.this, "��¼ʧ��", Toast.LENGTH_LONG).show();
				}
				
			}
		});
	}
	
	


}
