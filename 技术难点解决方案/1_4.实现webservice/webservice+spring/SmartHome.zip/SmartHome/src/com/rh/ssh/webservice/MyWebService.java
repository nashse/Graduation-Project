/**  
* @Title: 		MyWebService.java
* @Package: 		com.rh.ssh.webservice
* @Description: 	webservice类实现
* @author: 		rh_Jameson  
* @date:			2014年10月28日 上午9:34:35
*
*/ 
package com.rh.ssh.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import org.springframework.stereotype.Service;

/**
* 测试服务类
* Service注解为在使用Spring的packeage-scan功能进行自动装配
* WebService注解中可以不传递参数
* SOAPBinding中也可不传递参数，或者按照自己的需求进行更改
*/
@Service("myWebService")
@WebService(targetNamespace = "com.rh.ssh.webservice")
@SOAPBinding(style = Style.RPC)
public class MyWebService {
	
	/*
	 * 使用Spring来注入dao或service
	 * @Autowired
	 * private XXDao xxDao;
	 * */
	
	/**
	 * 接口方法必须加上WebMethod注解
	 */
	@WebMethod
	public void sayHello(){
		System.out.println("hello world");
	}
	
	
	
	
	
	
	

}
