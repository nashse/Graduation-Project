package com.servlet;
import java.io.IOException;
 

import java.util.ArrayList;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/websocket")

public class WebSocketTest{
	static private String isPlay = "playOff";
	static private ArrayList<RemoteEndpoint.Basic> arrayList = new ArrayList<RemoteEndpoint.Basic>();
	@OnMessage
	public void onMessage(String message, Session session)  throws IOException,
			InterruptedException {
			isPlay = message;
			System.out.println(arrayList.size());
			arrayList.get(1).sendText (isPlay);
			System.out.println(isPlay);


	}

	@OnOpen
	public void onOpen(Session session) throws IOException, InterruptedException {
		System.out.println("Client connected");
		arrayList.add(session.getBasicRemote());

	}

	@OnClose
	public void onClose() {
		arrayList.removeAll(arrayList);
		System.out.println("Connection closed");
	}
	
	
}

