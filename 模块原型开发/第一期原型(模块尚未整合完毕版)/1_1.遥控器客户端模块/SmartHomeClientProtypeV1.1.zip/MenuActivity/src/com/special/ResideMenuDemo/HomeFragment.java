package com.special.ResideMenuDemo;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.special.ResideMenu.ResideMenu;

import de.tavendo.autobahn.WebSocket;
import de.tavendo.autobahn.WebSocketConnection;
import de.tavendo.autobahn.WebSocketConnectionHandler;

/**
 * User: special
 * Date: 13-12-22
 * Time: 下午1:33
 * Mail: specialcyci@gmail.com
 */
public class HomeFragment extends Fragment {

    private View parentView;
    private ResideMenu resideMenu;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parentView = inflater.inflate(R.layout.home, container, false);
        setUpViews();
        next();
        return parentView;
    }

    
    /**
	 * websocket
	 */
		private WebSocket wsc = new WebSocketConnection();
	   private void next() {
		      try {
		    	  wsc.connect("ws://192.168.20.108:8080/WebSocketWebTest/websocket",
		    	  //wsc.connect("ws://ismartlife.duapp.com//WebSocketWebTest/websocket",
		                  new WebSocketConnectionHandler() {
		               
		                     @Override
		                     public void onOpen() {  
		                    	 //Toast.makeText(HomeFragment.this, "播发器open", Toast.LENGTH_LONG).show();                     
		                     }

		                     @Override
		                     public void onTextMessage(String payload) {
		                    	 //Toast.makeText(this, payload, Toast.LENGTH_LONG).show();                     
		                     
							
		                     }

		                     @Override
		                     public void onClose(int code, String reason) {
		                    	//Toast.makeText(MainActivity.this, "播发器Close", Toast.LENGTH_LONG).show();    
		                     }
		            });

		      
		   }catch(Exception e){
			   }
		   }

    private void setUpViews() {
        MenuActivity parentActivity = (MenuActivity) getActivity();
        resideMenu = parentActivity.getResideMenu();

        parentView.findViewById(R.id.btn_play_music).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            	wsc.sendTextMessage("playOn");
             //   resideMenu.openMenu(ResideMenu.DIRECTION_LEFT);
            }
        });

        // add gesture operation's ignored views
        FrameLayout ignored_view = (FrameLayout) parentView.findViewById(R.id.ignored_view);
        resideMenu.addIgnoredView(ignored_view);
    }

}
